<?php $__env->startSection('content'); ?>
<h2>Список заказов:</h2>
<table class="table table-bordered table-striped table-hover">
    <thead>
    <tr>
        <th>ID заказа</th>
        <th>ФИО</th>
        <th>Элементы заказа</th>
        <th>Сумма</th>
        <th>Выполнен</th>
    </tr>
    </thead>
    <tbody>
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($order->id); ?></td>
        <td><?php echo e($order->user->name); ?></td>
        <td><?php echo e($order->menu->name); ?></td>
        <td><?php echo e($order->menu->price); ?> сум</td>
        <td><a href="#" class="order_done">Выполнен</a></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/online.local/resources/views/orders/list.blade.php ENDPATH**/ ?>